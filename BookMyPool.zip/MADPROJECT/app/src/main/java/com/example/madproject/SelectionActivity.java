package com.example.madproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class SelectionActivity extends AppCompatActivity {

    private TextView nameTextView;
    private TextView ageTextView;
    private TextView mobileTextView;
    private TextView startingPointTextView;
    private TextView endingPointTextView;
    private TextView costChargedTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);
        Toolbar toolbar = findViewById(R.id.toolbar8);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("SELECTION");
        toolbar.setTitleTextColor(getResources().getColor(android.R.color.black));

        nameTextView = findViewById(R.id.textViewName);
        ageTextView = findViewById(R.id.textViewAge);
        mobileTextView = findViewById(R.id.textViewMobile);
        startingPointTextView = findViewById(R.id.textViewStartingPoint);
        endingPointTextView = findViewById(R.id.textViewEndingPoint);
        costChargedTextView = findViewById(R.id.textViewCostCharged);

        String name = getIntent().getStringExtra("name");
        int age = getIntent().getIntExtra("age", 0);
        String mobile = getIntent().getStringExtra("mobile");
        String startingPoint = getIntent().getStringExtra("startingPoint");
        String endingPoint = getIntent().getStringExtra("endingPoint");
        String costCharged = getIntent().getStringExtra("costCharged");

        nameTextView.setText("Name: " + name);
        ageTextView.setText("Age: " + String.valueOf(age));
        mobileTextView.setText("Mobile: " + mobile);
        startingPointTextView.setText("Starting Point: " + startingPoint);
        endingPointTextView.setText("Ending Point: " + endingPoint);
        costChargedTextView.setText("Cost Charged: " + costCharged);

        ImageView fabDelete = findViewById(R.id.floatingActionButton7);
        ImageView fabNext = findViewById(R.id.floatingActionButton6);

        fabDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        fabNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle next button click and navigate to NextActivity
                Intent intent = new Intent(SelectionActivity.this, PassengerConfirmationActivity.class);
                startActivity(intent);
            }
        });
    }
}
