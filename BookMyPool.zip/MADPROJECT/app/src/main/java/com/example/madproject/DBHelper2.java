package com.example.madproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper2 extends SQLiteOpenHelper {

    private static final String DB_NAME = "mydatabase.db";
    private static final int DB_VERSION = 2;

    private static final String TABLE_COLLECTION = "collection";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_AGE = "age";
    private static final String COLUMN_MOBILE = "mobile";
    private static final String COLUMN_STARTING_POINT = "starting_point";
    private static final String COLUMN_ENDING_POINT = "ending_point";
    private static final String COLUMN_COST_CHARGED = "cost_charged";

    public DBHelper2(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createCollectionTableQuery = "CREATE TABLE " + TABLE_COLLECTION + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_AGE + " INTEGER, " +
                COLUMN_MOBILE + " TEXT, " +
                COLUMN_STARTING_POINT + " TEXT, " +
                COLUMN_ENDING_POINT + " TEXT, " +
                COLUMN_COST_CHARGED + " INTEGER)";
        db.execSQL(createCollectionTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COLLECTION);
        onCreate(db);
    }

    public boolean insertCollectionDetails(String name, int age, String mobile, String startingPoint, String endingPoint, String costCharged) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_AGE, age);
        values.put(COLUMN_MOBILE, mobile);
        values.put(COLUMN_STARTING_POINT, startingPoint);
        values.put(COLUMN_ENDING_POINT, endingPoint);
        values.put(COLUMN_COST_CHARGED, costCharged);
        long result = db.insert(TABLE_COLLECTION, null, values);
        db.close();
        return result != -1;
    }

    public List<CollectionItem> getCollectionItems() {
        List<CollectionItem> collectionItems = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_COLLECTION, null);

        if (cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(COLUMN_ID);
                int nameIndex = cursor.getColumnIndex(COLUMN_NAME);
                int ageIndex = cursor.getColumnIndex(COLUMN_AGE);
                int mobileIndex = cursor.getColumnIndex(COLUMN_MOBILE);
                int startingPointIndex = cursor.getColumnIndex(COLUMN_STARTING_POINT);
                int endingPointIndex = cursor.getColumnIndex(COLUMN_ENDING_POINT);
                int costChargedIndex = cursor.getColumnIndex(COLUMN_COST_CHARGED);

                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                int age = cursor.getInt(ageIndex);
                String mobile = cursor.getString(mobileIndex);
                String startingPoint = cursor.getString(startingPointIndex);
                String endingPoint = cursor.getString(endingPointIndex);
                String costCharged = cursor.getString(costChargedIndex);

                CollectionItem collectionItem = new CollectionItem(id, name, age, mobile, startingPoint, endingPoint, costCharged);
                collectionItems.add(collectionItem);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return collectionItems;
    }
}
