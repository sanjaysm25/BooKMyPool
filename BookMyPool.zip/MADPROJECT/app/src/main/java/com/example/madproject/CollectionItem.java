package com.example.madproject;

public class CollectionItem {

    private String name;
    private int age;
    private String mobile;
    private String startingPoint;
    private String endingPoint;
    private String costCharged;

    public CollectionItem(int item, String name, int age, String mobile, String startingPoint, String endingPoint, String costCharged) {
        this.name = name;
        this.age = age;
        this.mobile = mobile;
        this.startingPoint = startingPoint;
        this.endingPoint = endingPoint;
        this.costCharged = costCharged;
    }


    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getMobile() {
        return mobile;
    }

    public String getStartingPoint() {
        return startingPoint;
    }

    public String getEndingPoint() {
        return endingPoint;
    }

    public String getCostCharged() {
        return costCharged;
    }
}
