package com.example.madproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class CollectionActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextAge;
    private EditText editTextMobile;
    private EditText editTextStartingPoint;
    private EditText editTextEndingPoint;
    private EditText editTextCostCharged;
    private Button buttonInsert;
    private Button buttonSeeDetails;

    private DBHelper2 dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection);
        Toolbar toolbar = findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("DRIVER DETAILS");
        toolbar.setTitleTextColor(getResources().getColor(android.R.color.black));
        toolbar.setNavigationIcon(R.drawable.ic_launcher_foreground);

        dbHelper = new DBHelper2(this);

        editTextName = findViewById(R.id.editTextText12);
        editTextAge = findViewById(R.id.editTextText11);
        editTextMobile = findViewById(R.id.editTextText10);
        editTextStartingPoint = findViewById(R.id.editTextText8);
        editTextEndingPoint = findViewById(R.id.editTextText7);
        editTextCostCharged = findViewById(R.id.editTextText14);
        buttonInsert = findViewById(R.id.buttonInsert);
        buttonSeeDetails = findViewById(R.id.buttonSeeDetails);

        buttonInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve data from EditText fields
                String name = editTextName.getText().toString();
                String ageText = editTextAge.getText().toString();
                String mobile = editTextMobile.getText().toString();
                String startingPoint = editTextStartingPoint.getText().toString();
                String endingPoint = editTextEndingPoint.getText().toString();
                String costCharged = editTextCostCharged.getText().toString();

                if (TextUtils.isEmpty(name) || TextUtils.isEmpty(ageText) || TextUtils.isEmpty(mobile) || TextUtils.isEmpty(startingPoint)
                        || TextUtils.isEmpty(endingPoint) || TextUtils.isEmpty(costCharged)) {
                    Toast.makeText(CollectionActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int age;
                try {
                    age = Integer.parseInt(ageText);
                } catch (NumberFormatException e) {
                    Toast.makeText(CollectionActivity.this, "Invalid age", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (age < 21) {
                    Toast.makeText(CollectionActivity.this, "Your not eligible", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (mobile.length() != 10) {
                    Toast.makeText(CollectionActivity.this, "Mobile number should be 10 digits", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean isInserted = dbHelper.insertCollectionDetails(name, age, mobile, startingPoint, endingPoint, costCharged);
                if (isInserted) {
                    Toast.makeText(CollectionActivity.this, "YOUR ENTRY IS COMPLETE", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(CollectionActivity.this, "FAILED", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonSeeDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve all the details from EditText fields
                String name = editTextName.getText().toString();
                String ageText = editTextAge.getText().toString();
                String mobile = editTextMobile.getText().toString();
                String startingPoint = editTextStartingPoint.getText().toString();
                String endingPoint = editTextEndingPoint.getText().toString();
                String costCharged = editTextCostCharged.getText().toString();

                if (TextUtils.isEmpty(name) || TextUtils.isEmpty(ageText) || TextUtils.isEmpty(mobile) || TextUtils.isEmpty(startingPoint)
                        || TextUtils.isEmpty(endingPoint) || TextUtils.isEmpty(costCharged)) {
                    Toast.makeText(CollectionActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int age;
                try {
                    age = Integer.parseInt(ageText);
                } catch (NumberFormatException e) {
                    Toast.makeText(CollectionActivity.this, "Invalid age", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (age < 21) {
                    Toast.makeText(CollectionActivity.this, " Eligible age > 21+", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (mobile.length() != 10) {
                    Toast.makeText(CollectionActivity.this, "Mobile number should be 10 digits", Toast.LENGTH_SHORT).show();
                    return;
                }

                ArrayList<String> collectionItems = new ArrayList<>();
                collectionItems.add("Name: " + name);
                collectionItems.add("Age: " + age);
                collectionItems.add("Mobile: " + mobile);
                collectionItems.add("Starting Point: " + startingPoint);
                collectionItems.add("Ending Point: " + endingPoint);
                collectionItems.add("Cost Charged: " + costCharged);

                Intent driverIntent = new Intent(CollectionActivity.this, DriverActivity.class);
                driverIntent.putStringArrayListExtra("collectionItems", collectionItems);
                startActivity(driverIntent);

                Intent displayIntent = new Intent(CollectionActivity.this, DisplayActivity.class);
                displayIntent.putStringArrayListExtra("collectionItems", collectionItems);
                startActivity(displayIntent);
            }

        });
    }
}
