package com.example.madproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<CollectionItem> {
    private Context context;
    private List<CollectionItem> collectionItems;

    public CustomAdapter(Context context, List<CollectionItem> collectionItems) {
        super(context, 0, collectionItems);
        this.context = context;
        this.collectionItems = collectionItems;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_collection, parent, false);

            viewHolder = new ViewHolder();
            viewHolder.textViewName = convertView.findViewById(R.id.textViewName);
            viewHolder.textViewAge = convertView.findViewById(R.id.textViewAge);
            viewHolder.textViewMobile = convertView.findViewById(R.id.textViewMobile);
            viewHolder.textViewStartingPoint = convertView.findViewById(R.id.textViewStartingPoint);
            viewHolder.textViewEndingPoint = convertView.findViewById(R.id.textViewEndingPoint);
            viewHolder.textViewCostCharged = convertView.findViewById(R.id.textViewCostCharged);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        CollectionItem item = collectionItems.get(position);

        viewHolder.textViewName.setText("Name: " + item.getName());
        viewHolder.textViewAge.setText("Age: " + item.getAge());
        viewHolder.textViewMobile.setText("Mobile: " + item.getMobile());
        viewHolder.textViewStartingPoint.setText("Starting Point: " + item.getStartingPoint());
        viewHolder.textViewEndingPoint.setText("Ending Point: " + item.getEndingPoint());
        viewHolder.textViewCostCharged.setText("Cost Charged: " + item.getCostCharged());

        return convertView;
    }

    private static class ViewHolder {
        TextView textViewName;
        TextView textViewAge;
        TextView textViewMobile;
        TextView textViewStartingPoint;
        TextView textViewEndingPoint;
        TextView textViewCostCharged;
    }
}
