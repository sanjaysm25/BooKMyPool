package com.example.madproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;



public class ChoiceActivity extends AppCompatActivity {

    private Button driverButton;
    private Button passengerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);

        Toolbar toolbar = findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("CHOOSE");
        toolbar.setTitleTextColor(getResources().getColor(android.R.color.black));

        driverButton = findViewById(R.id.button);
        passengerButton = findViewById(R.id.button3);

        driverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ChoiceActivity.this, DriverActivity.class));
                finish();
            }
        });

        passengerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ChoiceActivity.this, passengerActivity.class));
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_item1) {
            // Handle item 1 click
            Toast.makeText(this, "choice clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, ChoiceActivity.class));
            return true;
        } else if (itemId == R.id.action_item2) {
            // Handle item 2 click
            Toast.makeText(this, "driver clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, DriverActivity.class));
            return true;
        } else if (itemId == R.id.action_item3) {
            // Handle item 3 click
            Toast.makeText(this, "passenger clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, passengerActivity.class));
            return true;
        } else if (itemId == R.id.action_item4) {
            // Handle item 4 click (logout)
            Toast.makeText(this, "logging out", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity2.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
