package com.example.madproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.List;

public class passengerActivity extends AppCompatActivity {

    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger);
        Toolbar toolbar = findViewById(R.id.toolbar4);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(" DRIVER AVAILABLE");
        toolbar.setTitleTextColor(getResources().getColor(android.R.color.black));

        listView = findViewById(R.id.listview11);

        displayData();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle the item click and navigate to the appropriate activity
                CollectionItem selectedCollectionItem = (CollectionItem) parent.getItemAtPosition(position);
                if (selectedCollectionItem != null) {
                    Intent intent = new Intent(passengerActivity.this, SelectionActivity.class);
                    // Pass the item data to the activity using intent extras
                    intent.putExtra("name", selectedCollectionItem.getName());
                    intent.putExtra("age", selectedCollectionItem.getAge());
                    intent.putExtra("mobile", selectedCollectionItem.getMobile());
                    intent.putExtra("startingPoint", selectedCollectionItem.getStartingPoint());
                    intent.putExtra("endingPoint", selectedCollectionItem.getEndingPoint());
                    intent.putExtra("costCharged", selectedCollectionItem.getCostCharged());
                    startActivity(intent);
                }
            }
        });
    }

    private void displayData() {
        DBHelper2 dbHelper2 = new DBHelper2(this);
        List<CollectionItem> collectionItems = dbHelper2.getCollectionItems();
        dbHelper2.close();

        CustomAdapter customAdapter = new CustomAdapter(this, collectionItems);
        listView.setAdapter(customAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_passenger, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_logout) {
            // Handle logout click
            Toast.makeText(this, "Logging out", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
