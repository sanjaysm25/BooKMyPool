package com.example.madproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class PassengerConfirmationActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextMobile;
    private Button buttonConfirmBooking;
    private DBHelper3 dbHelper3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_confirmation);
        Toolbar toolbar = findViewById(R.id.toolbar10);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("ENTER PASSENGER DETAILS");
        toolbar.setTitleTextColor(getResources().getColor(android.R.color.black));
        toolbar.setNavigationIcon(R.drawable.baseline_add_circle_24);

        // Initialize views
        editTextName = findViewById(R.id.editTextText);
        editTextMobile = findViewById(R.id.editTextText2);
        buttonConfirmBooking = findViewById(R.id.button4);

        // Initialize DBHelper3
        dbHelper3 = new DBHelper3(this);

        buttonConfirmBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString().trim();
                String mobile = editTextMobile.getText().toString().trim();

                if (!name.isEmpty() && !mobile.isEmpty()) {

                    boolean isInserted = dbHelper3.insertPassengerDetails(name, mobile);

                    if (isInserted) {
                        Toast.makeText(PassengerConfirmationActivity.this, "Passenger details inserted successfully", Toast.LENGTH_SHORT).show();

                        editTextName.getText().clear();
                        editTextMobile.getText().clear();


                        Intent intent = new Intent(PassengerConfirmationActivity.this, PassengerComplitionActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(PassengerConfirmationActivity.this, "Failed to insert passenger details", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(PassengerConfirmationActivity.this, "Please enter name and mobile", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
