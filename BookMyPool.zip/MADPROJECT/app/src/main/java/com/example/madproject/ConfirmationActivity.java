package com.example.madproject;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


import java.util.List;


public class ConfirmationActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerViewAdapter adapter;
    private List<String> collectionItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);
        Toolbar toolbar = findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("BookMyPool");
        toolbar.setTitleTextColor(getResources().getColor(android.R.color.black));
        toolbar.setNavigationIcon(R.drawable.icon);

        Intent intent = getIntent();
        collectionItems = intent.getStringArrayListExtra("collectionItems");

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerViewAdapter(collectionItems);
        recyclerView.setAdapter(adapter);

        Button confirmButton = findViewById(R.id.button2);
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent resultIntent = new Intent();
                resultIntent.putStringArrayListExtra("collectionItems", new ArrayList<>(collectionItems));
                setResult(RESULT_OK, resultIntent);

                Intent driverCompletionIntent = new Intent(ConfirmationActivity.this, DriverComplitionActivity.class);
                startActivity(driverCompletionIntent);

                Button confirmButton = findViewById(R.id.button2);
                confirmButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent resultIntent = new Intent();
                        resultIntent.putStringArrayListExtra("collectionItems", new ArrayList<>(collectionItems));
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    }
                });
                finish();
            }
        });
    }
}
